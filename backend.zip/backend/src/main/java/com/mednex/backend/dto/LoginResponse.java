package com.mednex.backend.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class LoginResponse {
    private String token;
    private String username;
    private String email;
    private String firstName;
    private String lastName;
    private String tenantId;
    private String role;
}
